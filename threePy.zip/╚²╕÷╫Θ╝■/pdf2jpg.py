
'''
    =============================
    pdf2jpg,def后目录在img文件夹下
    =============================
'''
# 获取pdf目录下的pdf文件信息
pdfName = os.listdir(fatherUrl+'/pdf')
pdfNames = [] #pdf的文件名数组
for index in range(len(pdfName)):
    pdfNames.append(str(pdfName[index]))
imgNames = [] #切割后的img文件名数组

"""将pdf转图片,至当前目录下的img文件夹"""
# 在当前目录创建img文件夹
os.mkdir("img")
# 进入img文件夹
os.chdir(fatherUrl+'/img')

for pdfIndex in range(len(pdfNames)):

    # 第一个参数为拼接的pdf绝对路径,读取单个pdf,
    # PDF名为 ==> fatherUrl+'//pdf//'+pdfNames[i]
    pdf_im = PyPDF2.PdfFileReader(fatherUrl+'//pdf//'+pdfNames[pdfIndex], "rb")
    
    # 获取pdf页数
    pdf_num = pdf_im.getNumPages()

    print('第'+str(pdfIndex+1)+'个pdf文件一共'+str(pdf_num)+'页,文件名为【'+pdfNames[pdfIndex]+'】')
    for p in range(pdf_num):
        try:
            im = PythonMagick.Image()
            im.density('300')  # 设置dpi，不设置估计就96dpi
            im.read(fatherUrl+'//pdf//'+pdfNames[pdfIndex]+'['+str(p)+']')
            # 当前以在img目录下
            im.write(str(pdfNames[pdfIndex])[:-4] +'_'+ str(p+1) + '.jpg')
            imgNames.append(str(pdfNames[pdfIndex])[:-4] +'_'+ str(p+1) + '.jpg')
            print("正在处理第"+str(pdfIndex+1)+"个pdf文件  >>>   "+str(p+1)+"/"+str(pdf_num))
        except Exception as e:
            print('========================================')
            print('Skip the first page')
            print('========================================')
            continue
# 输出img下所有页的文件名,数组形式
print(imgNames)
