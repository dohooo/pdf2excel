'''
    =============================
    jpg调ocr识别,
    =============================
'''
# 选择目录
os.chdir(fatherUrl+'/img')
# 获取img目录下的文件信息
imgFileName = os.listdir()
imgFileNames = []
for index in range(len(imgFileName)):
    imgFileNames.append(str(imgFileName[index])[:-4])
# 输出img文件夹下的文件名（数组形式）
# print(imgFileNames)
#img数量
imgFileNamesLen=len(imgFileNames)
#返回根目录=>创建txt文件夹=>进入txt文件夹   （写入前进入目录）
os.chdir(fatherUrl)
os.mkdir('txt')
os.chdir(fatherUrl+'/txt')
print('共有'+str(imgFileNamesLen)+'个文件等待读取。')
print('------------------')
for txtIndex in range(len(imgFileName)):
    """ 读取图片 """
    def get_file_content(filePath):
        with open(filePath, 'rb') as fp:
            return fp.read()

    image = get_file_content(fatherUrl+'/img/'+imgFileName[txtIndex])
    print('正在读取【'+imgFileName[txtIndex]+'】'+'   进度为：'+str(txtIndex)+'/'+str(imgFileNamesLen))
    """ 如果有可选参数 """
    options = {}
    options["detect_direction"] = "true"
    options["probability"] = "true"
    templateSign = "f3b35f4c3d36db6b89c9608ea288d8b6"
    """ 带参数调用通用文字识别, 图片参数为本地图片 """

    try:
        result = client.custom(image, templateSign)
    except Exception as e: 
        print('请检查当前网络,问题如下：')
        print(e)
        continue
    # else:
        # print(result)

    try:
        if str(result['data']['isStructured'])=='False':
            ocrFalseImg.append(imgFileName[txtIndex])
            print('------------------')
            print('【'+str(imgFileName[txtIndex])+'】'+'   结构化不匹配,跳过【文件写入】循环')
            print('------------------')
            continue
        print('------------------')
        print('构化匹配成功！开始进行文件写入...')
        print('------------------')
    except Exception as e: 
        print(e)
        continue

    try:

        for i in range(len(result['data']['ret'])):
            with open(imgFileNames[txtIndex]+r'.txt', 'a') as f:
                f.write(result['data']['ret'][i]['word']+'\n')
                print('成功写入=>'+str(result['data']['ret'][i]['word_name']))
                print('------------------')
        print('【'+imgFileNames[txtIndex]+r'.txt'+'】'+'   写入成功！')
        print('------------------')
        
        
    except Exception as e: 
        print(e)
print('本次数据筛选写入完成,以下是不符合构化的图片文件:')
print('==========================================')
print(ocrFalseImg)