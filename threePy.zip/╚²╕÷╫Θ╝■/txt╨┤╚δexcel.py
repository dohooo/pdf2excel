
'''
    =============================
    txt写入excel
    =============================
'''
# 选择目录
os.chdir(fatherUrl+'/txt')
# 获取txt目录下的文件信息
txtFileName = os.listdir()
txtFileNames = []
for index in range(len(txtFileName)):
    txtFileNames.append(str(txtFileName[index])[:-4])
# 输出txt文件夹下的文件名（数组形式）
# print(txtFileNames)
#txt数量
txtFileNamesLen=len(txtFileNames)
#返回根目录=>创建txt文件夹=>进入txt文件夹   （写入前进入目录）
os.chdir(fatherUrl)
os.mkdir('excel')
os.chdir(fatherUrl+'/excel')
print('共有'+str(txtFileNamesLen)+'个文件等待读取。')
print('------------------')
# 生成对应文件长度的数组
for arrIndex in range(len(txtFileName)):
    data={'date': [], 'id': [], 'arr': []}
for fileIndex in range(len(txtFileName)):
    file = open(fatherUrl+'/txt/'+str(txtFileName[fileIndex]))
    while 1:
        lines = file.readlines()
        if not lines:
            break
        for index in range(len(lines)):
            newLine = ''.join(lines[index]).strip('\n')

            """处理字符串"""
            threeLine=''.join(lines[2]).strip('\n')       
            # 截取前六位
            txtIndex=threeLine[0:6]
            # 替换前六位变成 （,*****）
            newTxt=threeLine.replace(txtIndex,','+txtIndex)
            # 字符串转数组
            txtArr=newTxt.split(',')
            # 删除数组第一项
            del txtArr[0]

            


            if str(index) == '0':
                for dateIndex in range(len(txtArr)):
                    data['date'].append(newLine)
            elif str(index) == '1':
                for dateIndex in range(len(txtArr)):
                    data['id'].append(newLine)
            elif str(index) == '2':
                for i in range(len(txtArr)):
                    data['arr'].append(txtArr[i])
    # print(data)
    file.close()
print(data)

def set_style(name, height, bold=False):
    style = xlwt.XFStyle()  # 初始化样式
    font = xlwt.Font()  # 为样式创建字体
    font.name = name  # 'Times New Roman'
    font.bold = bold
    font.color_index = 4
    font.height = height
    style.font = font
    return style

# 写excel
def write_excel():  
    f = xlwt.Workbook()  # 创建工作簿

    '''
  创建第一个sheet:
    sheet1
  '''
    sheet1 = f.add_sheet(u'sheet2', cell_overwrite_ok=True)  # 创建sheet
    row0 = [u'报告编号', u'焊缝编号', u'检测日期']

    # 生成第一行
    for i in range(0, len(row0)):
        sheet1.write(0, i, row0[i])
    # 为1至3列写入数据库
    for j in range(0, 3):
        if j==0:
            for index_date in range(len(data['date'])):
                sheet1.write(index_date+1,0,data['id'][index_date])
        if j==1:
            for index_date in range(len(data['date'])):
                sheet1.write(index_date+1,1,data['arr'][index_date])
        if j==2:
            for index_date in range(len(data['date'])):
                sheet1.write(index_date+1,2,data['date'][index_date])
    # 保存文件
    f.save('test.xls')  


if __name__ == '__main__':
    write_excel()

print('已生成一个excel')
